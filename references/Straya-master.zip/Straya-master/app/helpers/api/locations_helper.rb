module Api::LocationsHelper
end
