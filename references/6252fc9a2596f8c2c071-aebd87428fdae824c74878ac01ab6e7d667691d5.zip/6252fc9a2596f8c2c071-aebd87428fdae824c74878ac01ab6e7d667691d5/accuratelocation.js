getAccurateCurrentPosition = function (geolocationSuccess, geolocationError, geoprogress, options) {
    var lastCheckedPosition,
        locationEventCount = 0,
        watchID,
        timerID;

    options = options || {};

    var checkLocation = function (position) {
        lastCheckedPosition = position;
        locationEventCount = locationEventCount + 1;
        // We ignore the first event unless it's the only one received because some devices seem to send a cached
        // location even when maxaimumAge is set to zero
        if ((position.coords.accuracy <= options.desiredAccuracy) && (locationEventCount > 1)) {
            clearTimeout(timerID);
            navigator.geolocation.clearWatch(watchID);
            foundPosition(position);
        } else {
            geoprogress(position);
        }
    };

    var stopTrying = function () {
        navigator.geolocation.clearWatch(watchID);
        foundPosition(lastCheckedPosition);
    };

    var onError = function (error) {
        clearTimeout(timerID);
        navigator.geolocation.clearWatch(watchID);
        geolocationError(error);
    };

    var foundPosition = function (position) {
        geolocationSuccess(position);
    };

    if (!options.maxWait)            options.maxWait = 10000; // Default 10 seconds
    if (!options.desiredAccuracy)    options.desiredAccuracy = 20; // Default 20 meters
    if (!options.timeout)            options.timeout = options.maxWait; // Default to maxWait

    options.maximumAge = 0; // Force current locations only
    options.enableHighAccuracy = true; // Force high accuracy (otherwise, why are you using this function?)

    watchID = navigator.geolocation.watchPosition(checkLocation, onError, options);
    timerID = setTimeout(stopTrying, options.maxWait); // Set a timeout that will abandon the location loop
};

//The following code should go in your controller

    function onSuccess(position) {
        el = document.getElementById("locate-icon");
        el.classList.add("ion-pinpoint");
        el.classList.remove("ion-loading-a");
        marker = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            focus: true
        };
        $scope.markers["currentloc"] = marker;

        //for some reason leaflet does not want to add a marker after we've
        //already gotten them from the cache, so we have to manually add
        //the currentloc marker and remove the old one
        leafletData.getMap().then(function(map) {
            if(currentloc !== undefined){
                map.removeLayer(currentloc);
            }
            currentloc = L.marker([marker.lat, marker.lng]);
            currentloc.addTo(map);
            map.panTo([marker.lat, marker.lng]);
        });

    }

    function onError(error) {
        alert('code: '    + error.code    + '\n' +
              'message: ' + error.message + '\n');
    }

    function onWait(){
        el = document.getElementById("locate-icon");
        el.classList.remove("ion-pinpoint");
        el.classList.add("ion-loading-a");
        console.log("waiting...");
    }

    $scope.markLocation = function(){
        getAccurateCurrentPosition(onSuccess, onError, onWait);
    };